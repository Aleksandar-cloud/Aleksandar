for num in range (1500,2701,5):
    if num%7==0:
        print(num)