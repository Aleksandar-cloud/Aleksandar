def powerlist(myList):
    power=1
    for num in myList:
        power=power*num
    return power

samplelist=(8,2,3,-1,7)
print("power=",powerlist(samplelist))