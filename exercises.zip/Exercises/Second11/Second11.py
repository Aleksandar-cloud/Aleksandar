def revStr(myStr):
    l = len(myStr)
    revMyStr = ""
    for i in range(l - 1, -1, -1):
        revMyStr = revMyStr+str(myStr[i])
    return revMyStr

def isPalendrome(myStr):
    if myStr == revStr(myStr):
        return True
    else:
        return False

myString = input("Enter String:")
if isPalendrome(myString):
    print(myString," is Palindrome")
else:
    print(myString,"Is not Palindrome")
