def factorial(myNum):
    fact=1
    for num in range(1,myNum+1):
        fact=fact*num
    return fact

number=int(input("Enter n="))
print(number,"!=",factorial(number))
