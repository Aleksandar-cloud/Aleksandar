sourceTemperature = input('Enter source Temperature:')
if sourceTemperature == 'c':
    c = int(input('Enter c:'))
    f= 9*c/5+32
    print(str(c)+ 'C is ' +str(f)+' in Fahrenheit')
elif sourceTemperature == 'f':
    f = int(input('Enter f:'))
    c = 5*(f-32)/9
    print(str(f) + 'F is ' + str(c) + ' in Celsius')
else:
    print("Error")