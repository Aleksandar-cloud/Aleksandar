import random
num = random.randint(1,9)
while True:
    ans = int(input('Enter Number'))
    if ans == num:
        print('Well guessed!')
        break
