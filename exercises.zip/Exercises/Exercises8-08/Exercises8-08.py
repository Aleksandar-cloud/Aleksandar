for i in range(1,7):
    if i==3 or i==6:
        continue
    print(i)