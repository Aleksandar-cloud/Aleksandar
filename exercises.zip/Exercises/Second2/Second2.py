def sumlist(myList):
    sum=0
    for num in myList:
        sum=sum+num
    return sum

samplelist=(8,2,3,0,7)
print("sum=",sumlist(samplelist))