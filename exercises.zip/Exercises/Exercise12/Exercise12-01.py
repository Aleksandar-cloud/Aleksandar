row=input('Enter Row:')
while row!="":
    row2 = row.lower()
    print(row2)
    row = input('Enter Row:')