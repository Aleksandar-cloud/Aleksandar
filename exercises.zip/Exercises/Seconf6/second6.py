def numinrange(a,b,n):
    if n>=a and n<=b:
        return True
    else:
        return False

numA = int(input("Enter left value of range:"))
numB = int(input("Enter right value of range:"))
numN = int(input("Enter Number"))
if numinrange(numA,numB,numN):
    print("Number in range")
else:
    print("Number is not in range")

