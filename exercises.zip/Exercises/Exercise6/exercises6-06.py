numbers = (1, 2, 3, 4, 5, 6, 7, 8, 9)
countEven = 0
countOdd = 0
for num in numbers:
    if num%2==0:
        countEven=countEven+1
    else:
        countOdd=countOdd+1
print('Number of even numbers :',countEven)
print('Number of Odd numbers :',countOdd)
