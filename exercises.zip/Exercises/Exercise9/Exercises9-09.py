tib1 = 0
tib2 = 1
while(tib2<50):
    print(tib2,end = ",")
    temp = tib1+tib2
    tib1 = tib2
    tib2 = temp