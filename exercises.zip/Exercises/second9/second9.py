def isPrime(myNum):
    for i in range(2,myNum):
        if myNum%i == 0:
            return False
    return True

number = int(input("Enter number:"))
if isPrime(number):
    print("Number is prime")
else:
    print("Number is not prime")