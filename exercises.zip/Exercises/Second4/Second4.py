def revStr(myStr):
    l = len(myStr)
    revMyStr = ""
    for i in range(l - 1, -1, -1):
        revMyStr = revMyStr+str(myStr[i])
    return revMyStr

myString = input("Enter String:")
print('Reverse string:',revStr(myString))
