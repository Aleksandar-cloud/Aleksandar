word = input("Enter Word:")
l = len(word)
print('Reverse word:' ,end = ' ')
for i in range(l-1,-1,-1):
    print(word[i],end = '')
print('\n')