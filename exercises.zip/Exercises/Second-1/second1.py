def max3num(numA,numB,numC):
    max=numA
    if max<numB:
        max=numB
    if max<numC:
        max=numC
    return max

numberA=int(input('Enter A='))
numberB=int(input('Enter B='))
numberC=int(input('Enter C='))
print('max:',max3num(numberA,numberB,numberC))