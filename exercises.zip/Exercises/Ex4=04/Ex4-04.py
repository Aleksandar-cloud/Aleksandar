for row in range(1,6):
    for star in range (1,row+1):
        print('*', end = "")
    print('\n')

for row in range(1,5):
    for star in range (1,6-row):
        print('*', end = "")
    print('\n')
